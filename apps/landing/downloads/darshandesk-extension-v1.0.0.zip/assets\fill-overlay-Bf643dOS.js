const e="dd-fill-overlay-root",r=`
  #${e} {
    position: fixed;
    inset: 0;
    z-index: 2147483646;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(28, 25, 23, 0.35);
    backdrop-filter: blur(2px);
    font-family: 'DM Sans', system-ui, sans-serif;
    pointer-events: none;
  }
  #${e} .dd-fill-card {
    pointer-events: auto;
    min-width: 220px;
    max-width: min(92vw, 320px);
    padding: 18px 22px;
    border-radius: 12px;
    background: linear-gradient(145deg, #ffffff 0%, #fff5f5 100%);
    border: 1px solid #fecaca;
    box-shadow: 0 12px 40px rgba(0, 0, 0, 0.22);
    text-align: center;
    color: #1c1917;
  }
  #${e} .dd-fill-spinner {
    width: 32px;
    height: 32px;
    margin: 0 auto 12px;
    border: 3px solid #e7e5e4;
    border-top-color: #B80012;
    border-radius: 50%;
    animation: dd-fill-spin 0.75s linear infinite;
  }
  #${e} .dd-fill-title {
    margin: 0;
    font-size: 14px;
    font-weight: 700;
  }
  #${e} .dd-fill-status {
    margin: 6px 0 0;
    font-size: 12px;
    color: #57534e;
    line-height: 1.35;
  }
  @keyframes dd-fill-spin {
    to { transform: rotate(360deg); }
  }
`;let d=null;function s(t){d!=null&&d.isConnected||(d=t.createElement("style"),d.textContent=r,t.documentElement.appendChild(d))}function f(t,i,l="DarshanDesk autofill"){o(t),s(t);const n=t.createElement("div");n.id=e,n.setAttribute("role","status"),n.setAttribute("aria-live","polite"),n.innerHTML=`
    <div class="dd-fill-card">
      <div class="dd-fill-spinner" aria-hidden="true"></div>
      <p class="dd-fill-title">${l}</p>
      <p class="dd-fill-status" data-dd-status></p>
    </div>
  `;const a=n.querySelector("[data-dd-status]");a&&(a.textContent=i),t.body.appendChild(n)}function p(t,i){const l=t.querySelector(`#${e} [data-dd-status]`);l&&(l.textContent=i)}function o(t){var i;(i=t.getElementById(e))==null||i.remove()}export{o as h,f as s,p as u};
